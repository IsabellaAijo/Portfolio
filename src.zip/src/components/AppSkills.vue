<template>
    <h2>This is the skills section dude</h2>
</template>