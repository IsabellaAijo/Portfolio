<template>
    <h2>Here go the projects man</h2>
</template>