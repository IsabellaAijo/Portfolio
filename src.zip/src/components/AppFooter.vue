<template>
  <hr class="mt-5 mb-4">
  <p class="text-muted">Here's something to put in footer idk bruh</p>
</template>
