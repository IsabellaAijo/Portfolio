<template>
    <h2>The worst part is I hope no one contacts me bro</h2>
</template>