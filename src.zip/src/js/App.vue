<script setup>
import Header from '../components/AppHeader.vue'
import Guides from '../components/AppGuides.vue'
import Skills from '../components/AppSkills.vue'
import Projects from '../components/AppProjects.vue'
import Contact from '../components/AppContact.vue'
import Footer from '../components/AppFooter.vue'
</script>

<template>
  <div class="container py-4 px-3 mx-auto">
    <!-- AppHeader.vue -->
    <!-- <Header /> -->

    <div class="main-header">
      <h1>Hi.</h1>
    <h1>I hope this works.</h1>
    </div>
    
    <div class="main-text">
      <p class="fs-4">Here is a little paragraph that talks about something. If 
        anything, which in this case is everything, I don't want it to be gay. 
        That would hell. Dick and balls. Lmao.
      </p>
    </div>

    <!--<button type="blue-button" class="btn btn-primary me-3" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample">Toggle offcanvas</button>
    <a id="example-popoverButton" class="text-success" href="#" role="button" data-bs-toggle="popover" title="Custom popover" data-bs-content="This is a Bootstrap popover.">Example popover</a>
    -->

    <!-- Off Canvas Menu-->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasExampleLabel">Offcanvas</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <div>
          Some text as placeholder. In real life you can have the elements you have chosen. Like, text, images, lists, etc.
        </div>
        <div class="dropdown mt-3">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown">
            Dropdown button
          </button>
          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </div>
      </div>
    </div>
    <!-- End of Off Canvas Menu-->

    <hr class="col-1 my-5 mx-0">
    <Skills />

    <hr class="col-1 my-5 mx-0">
    <Projects />

    <hr class="col-1 my-5 mx-0">
    <Contact />

    <!-- AppFooter.vue -->
    <Footer />
  </div>
</template>
